package com.demo123;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo123Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo123Application.class, args);
	}

}
